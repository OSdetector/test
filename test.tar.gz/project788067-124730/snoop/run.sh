#! /bin/bash
sudo ./top_snoop.py \
-c "./test/higtest/high_cpu_testt" \
--configure_file ./config.json
