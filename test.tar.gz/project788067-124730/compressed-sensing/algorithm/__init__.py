from .sampling import localized_sample
