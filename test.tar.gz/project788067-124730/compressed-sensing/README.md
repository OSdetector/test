# jumpstarter

## Dependencies

numpy==1.21.5
pandas==1.4.2
PyYAML==6.0
scikit_learn==1.1.2
scipy==1.7.3